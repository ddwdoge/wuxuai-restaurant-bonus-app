import type { CSSProperties, ReactNode } from "react";
import {
  normalizeRewardImageCrop,
  type RewardImageCrop,
} from "../rewardImageCrop";
import "./reward-image-frame.css";

type RewardImageFrameProps = {
  alt: string;
  className?: string;
  crop?: Partial<RewardImageCrop> | null;
  fallback?: ReactNode;
  imageUrl?: string | null;
};

export function RewardImageFrame({ alt, className = "", crop, fallback, imageUrl }: RewardImageFrameProps) {
  const normalized = normalizeRewardImageCrop(crop);
  const style = {
    "--reward-image-position-x": `${normalized.positionX * 100}%`,
    "--reward-image-position-y": `${normalized.positionY * 100}%`,
    "--reward-image-zoom": normalized.zoom,
  } as CSSProperties;

  return (
    <div className={`reward-image-frame ${className}`.trim()} style={style}>
      {imageUrl ? <img alt={alt} draggable={false} src={imageUrl} /> : fallback}
    </div>
  );
}
