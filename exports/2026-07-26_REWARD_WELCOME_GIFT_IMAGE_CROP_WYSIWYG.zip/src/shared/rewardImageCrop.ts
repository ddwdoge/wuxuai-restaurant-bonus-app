export type RewardImageCrop = {
  zoom: number;
  positionX: number;
  positionY: number;
};

export const DEFAULT_REWARD_IMAGE_CROP: RewardImageCrop = {
  zoom: 1,
  positionX: 0.5,
  positionY: 0.5,
};

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, Number.isFinite(value) ? value : min));
}

export function normalizeRewardImageCrop(input?: Partial<RewardImageCrop> | null): RewardImageCrop {
  return {
    zoom: clamp(Number(input?.zoom ?? 1), 1, 4),
    positionX: clamp(Number(input?.positionX ?? 0.5), 0, 1),
    positionY: clamp(Number(input?.positionY ?? 0.5), 0, 1),
  };
}

export function rewardImageCropFromRecord(record?: {
  image_zoom?: number | null;
  image_position_x?: number | null;
  image_position_y?: number | null;
} | null) {
  return normalizeRewardImageCrop({
    zoom: record?.image_zoom ?? 1,
    positionX: record?.image_position_x ?? 0.5,
    positionY: record?.image_position_y ?? 0.5,
  });
}
