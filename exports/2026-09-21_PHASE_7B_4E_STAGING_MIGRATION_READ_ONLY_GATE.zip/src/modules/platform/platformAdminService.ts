import { supabase } from "../../shared/lib/supabase";

export type SubscriptionStatus = "trialing" | "active" | "past_due" | "unpaid" | "cancelled" | "paused";
export type PaymentStatus = "not_required" | "pending" | "paid" | "failed" | "manual";
export type RestaurantStatus = "active" | "draft" | "suspended";
export type CommercialPlan = "BASIC" | "PRO" | "PREMIUM";

export type PlatformRestaurantLegalI18nStatus = {
  restaurant_id: string;
  preferred_language: string | null;
  business_country: string | null;
  legal_jurisdiction_status: "available" | "unavailable";
  legal_jurisdiction: string | null;
  legal_jurisdiction_source: string | null;
  legal_review_status: "required" | "in_review" | "reviewed" | null;
  published_documents: Array<{
    document_type: string;
    version: string;
    language: string;
    effective_date: string;
    legal_country: string | null;
    acceptance_count: number;
  }>;
};

export type RestaurantEntitlements = {
  contract_version?: string;
  effective_plan?: CommercialPlan;
  stored_plan_key?: CommercialPlan | null;
  entitlement_source?: string;
  effective_from?: string | null;
  effective_until?: string | null;
  override_status?: string;
  subscription_status?: string | null;
  payment_status?: string | null;
  restaurant_id: string;
  subscription_id: string | null;
  plan_key: CommercialPlan;
  monthly_price_eur_ex_vat: number;
  publicly_available: boolean;
  active_offer_count: number;
  commercial_default: EntitlementValues;
  override: (Partial<EntitlementValues> & {
    id?: string | null;
    plan_key?: CommercialPlan | null;
    status?: string;
    effective_from?: string | null;
    expires_at?: string | null;
    reason: string;
    changed_by: string;
    changed_at: string;
  }) | null;
  effective: EntitlementValues;
  stripe_mapping: { lookup_key: string | null; configured: false };
};

export type EntitlementValues = {
  offer_limit: number | null;
  offer_limit_unlimited: boolean;
  offer_notifications: boolean;
  reward_notifications: boolean;
  gift_cards: false;
  pos_integration: false;
};

export type PlatformSummary = {
  restaurants_total: number;
  active_restaurants?: number;
  active_trials: number;
  expiring_trials?: number;
  expired_trials: number;
  suspended_restaurants?: number;
  new_restaurants_today?: number;
  active_subscriptions: number;
  open_payments: number;
  points_today: number;
  redemptions_today: number;
};

export type PlatformRestaurant = {
  id: string;
  name: string;
  slug: string;
  status: RestaurantStatus;
  onboarding_status: string | null;
  created_at: string;
  owner_id: string;
  owner_email: string | null;
  owner_name: string | null;
  organization_id: string | null;
  branch_id: string | null;
  subscription_id: string | null;
  subscription_exists: boolean;
  subscription_status: SubscriptionStatus | null;
  payment_status: PaymentStatus | null;
  trial_started_at: string | null;
  trial_ends_at: string | null;
  current_period_end: string | null;
  paused_at: string | null;
  locked_at: string | null;
  lock_reason: string | null;
  trial_days_left: number | null;
  customer_count: number;
  points_today: number;
  points_total: number;
  redemptions_count: number;
  last_activity_at: string | null;
};

type PlatformRestaurantsResponse = {
  summary?: Partial<PlatformSummary>;
  restaurants?: PlatformRestaurant[];
};

const emptySummary: PlatformSummary = {
  restaurants_total: 0,
  active_restaurants: 0,
  active_trials: 0,
  expiring_trials: 0,
  expired_trials: 0,
  suspended_restaurants: 0,
  new_restaurants_today: 0,
  active_subscriptions: 0,
  open_payments: 0,
  points_today: 0,
  redemptions_today: 0,
};

function normalizeSummary(summary?: Partial<PlatformSummary>): PlatformSummary {
  return {
    restaurants_total: Number(summary?.restaurants_total ?? 0),
    active_restaurants: Number(summary?.active_restaurants ?? 0),
    active_trials: Number(summary?.active_trials ?? 0),
    expiring_trials: Number(summary?.expiring_trials ?? 0),
    expired_trials: Number(summary?.expired_trials ?? 0),
    suspended_restaurants: Number(summary?.suspended_restaurants ?? 0),
    new_restaurants_today: Number(summary?.new_restaurants_today ?? 0),
    active_subscriptions: Number(summary?.active_subscriptions ?? 0),
    open_payments: Number(summary?.open_payments ?? 0),
    points_today: Number(summary?.points_today ?? 0),
    redemptions_today: Number(summary?.redemptions_today ?? 0),
  };
}

export type PlatformAuditEntry = {
  id: string;
  created_at: string;
  action: string;
  actor_type: string;
  actor_id: string | null;
  target_table: string | null;
  target_id: string | null;
};

export type PlatformAuditEvent = {
  id: string;
  created_at: string;
  restaurant_id: string;
  restaurant_name: string;
  customer_id: string | null;
  actor_type: string;
  actor_id: string | null;
  event_type: string;
  status: "success" | "failed" | "blocked";
  source: string | null;
  entity_type: string | null;
  entity_id: string | null;
  request_id: string | null;
  is_test_event: boolean;
  test_session_id: string | null;
  metadata: Record<string, unknown>;
  error_code: string | null;
  error_message: string | null;
};

export type PlatformAuditFilters = {
  from?: string | null;
  to?: string | null;
  restaurantId?: string | null;
  customerId?: string | null;
  eventType?: string | null;
  status?: PlatformAuditEvent["status"] | null;
  source?: string | null;
  actorType?: string | null;
  testOnly?: boolean;
  failedOnly?: boolean;
  limit?: number;
};

export type PlatformRestaurantDetail = {
  restaurant: PlatformRestaurant & {
    owner_phone?: string | null;
    restaurant_type?: string | null;
    language?: string | null;
  };
  branding: {
    logo_url: string | null;
    primary_color: string | null;
    secondary_color: string | null;
    button_color: string | null;
  } | null;
  metrics: {
    customer_count: number;
    points_transactions_count: number;
    points_today: number;
    points_total: number;
    redemptions_today: number;
    redemptions_total: number;
    welcome_gifts_total: number;
    welcome_gifts_active: number;
    bonus_boosts_active: number;
  };
  audit: PlatformAuditEntry[];
};

export type PlatformMetric<T> =
  | { status: "available"; value: T }
  | { status: "unavailable"; value: null };

export type PlatformSubsystemHealth = "healthy" | "warning" | "error" | "unavailable";

export type PlatformOperationalStatus = "healthy" | "no_recent_events" | "degraded" | "error" | "unavailable";

export type PlatformOperationalTelemetry = {
  contract_version: "platform_operational_telemetry_v1";
  generated_at: string;
  cron: {
    status: PlatformOperationalStatus;
    reason: string | null;
    expected_job_count: number;
    configured_job_count: number;
    enabled_job_count: number;
    last_run_at: string | null;
    last_success_at: string | null;
    last_failure_at: string | null;
    failures_24h: number;
    jobs: Array<{ name: string; configured: boolean; enabled: boolean; schedule: string | null; last_status: string | null; last_run_at: string | null }>;
  };
  email: {
    status: PlatformOperationalStatus;
    reason: string | null;
    configuration_status: "unavailable";
    configuration_reason: string;
    pending_count: number;
    processing_count: number;
    failed_count: number;
    sent_24h_count: number;
    last_sent_at: string | null;
    last_failure_at: string | null;
  };
  registration: {
    status: PlatformOperationalStatus;
    reason: string | null;
    success_24h: number;
    success_7d: number;
    failures_24h: number;
    failures_7d: number;
    last_success_at: string | null;
    last_failure_at: string | null;
  };
};

export type PlatformHealthSeverity = "P0" | "P1" | "P2" | "P3";
export type PlatformHealthCategory = "ONBOARDING" | "LOCATION" | "LEGAL" | "PLAN" | "BONUS" | "COUNTRY" | "SYSTEM";

export type PlatformHealthFinding = {
  id: string;
  type: string;
  severity: PlatformHealthSeverity;
  category: PlatformHealthCategory;
  current: unknown;
  expected: unknown;
  first_seen_at: string | null;
  first_seen_status: "unavailable";
  last_checked_at: string;
  recommendation: string;
  audit: { status?: string; id?: string; timestamp?: string; event_key?: string };
  target: {
    type: "restaurant" | "country" | "system";
    restaurant_id?: string;
    restaurant_name?: string;
    location_id?: string;
    country?: string;
    plan?: string;
    system_area?: string;
    route: string;
  };
};

export type PlatformHealthRestaurantTarget = {
  restaurant_id: string;
  restaurant_name: string;
  location_id?: string;
  country?: string;
  plan?: string;
  finding_count: number;
  status: "HEALTHY" | "ATTENTION";
  route: string;
};

export type PlatformHealthCenter = {
  contract_version: "platform_health_center_v1";
  generated_at: string;
  freshness: {
    status: "current";
    generated_at: string;
    claim: "snapshot_at_request_time";
    automatic_refresh: false;
  };
  summary: {
    critical: number;
    errors: number;
    warnings: number;
    notices: number;
    healthy: number;
    findings_total: number;
    restaurants_checked: number;
  };
  findings: PlatformHealthFinding[];
  restaurant_targets: PlatformHealthRestaurantTarget[];
};

export type PlatformRestaurantControlCenter = {
  contract_version: "platform_restaurant_control_center_v1";
  generated_at: string;
  timezone: string;
  overall_health: "healthy" | "warning" | "error" | "unknown";
  account: {
    restaurant_id: string;
    restaurant_name: string;
    restaurant_status: RestaurantStatus;
    onboarding_status: string | null;
    setup_completed: boolean;
    owner: { user_id: string; name: string | null; business_email: string | null };
    created_at: string;
    last_activity_at: string | null;
    internal_test: PlatformMetric<boolean>;
  };
  subscription: PlatformMetric<{
    subscription_status: SubscriptionStatus | null;
    payment_status: PaymentStatus | null;
    plan_key: string;
    trial_started_at: string | null;
    trial_ends_at: string | null;
    trial_days_remaining: number | null;
    current_period_end: string | null;
  }>;
  usage: {
    customers_total: PlatformMetric<number>;
    customers_new_30d: PlatformMetric<number>;
    points_today: PlatformMetric<number>;
    points_30d: PlatformMetric<number>;
    welcome_gifts_active: PlatformMetric<number>;
    birthday_gifts_active: PlatformMetric<number>;
  };
  redemption: {
    health: PlatformSubsystemHealth;
    redemptions_today: PlatformMetric<number>;
    redemptions_30d: PlatformMetric<number>;
    last_redemption_at: PlatformMetric<string | null>;
    breakdown_30d: { points: number; welcome: number; birthday: number };
    failures_24h: number;
  };
  referral:
    | {
        status: "available";
        health: PlatformSubsystemHealth;
        enabled: boolean;
        multiplier: 2;
        configured_duration_days: number;
        duration_type: "preset" | "custom";
        monthly_invite_limit: number;
        friend_duration_ratio: 0.5;
        qualified_referrals_30d: number;
        active_boosters: number;
        boost_extra_points_30d: number;
        last_qualified_referral_at: string | null;
      }
    | { status: "unavailable"; health: "unavailable"; value: null };
  health: {
    registration: {
      status: PlatformSubsystemHealth;
      last_success: string | null;
      failures_24h: number;
      failures_7d: number;
    };
    email: {
      status: PlatformSubsystemHealth;
      last_success: string | null;
      last_failure: string | null;
      failed_24h: number;
      pending_retry_count: number;
    };
    geolocation: {
      status: PlatformSubsystemHealth;
      address_complete: boolean | null;
      coordinates_present: boolean | null;
      public_search_eligible: boolean | null;
      last_geocode_status: PlatformMetric<string>;
    };
    staff: {
      status: PlatformSubsystemHealth;
      staff_count: PlatformMetric<number>;
      daily_pin_available: PlatformMetric<boolean>;
      qr_flow_available: PlatformMetric<boolean>;
    };
    cron: {
      status: "unavailable";
      last_success: null;
      last_failure: null;
      failure_count: null;
      reason: string;
    };
  };
  audit: Array<{
    id: string;
    timestamp: string;
    actor_type: string;
    actor_label: string;
    event_key: string;
    event_label: string;
    status: "success" | "failed" | "blocked";
    target_type: string | null;
    target_id: string | null;
    before: Record<string, string | null> | null;
    after: Record<string, string | null> | null;
  }>;
  capabilities: {
    restaurant_status_change: "supported";
    subscription_update: "supported";
    trial_extension: "supported";
    manual_payment: { status: "deferred"; reason: string };
  };
};

export type PlatformOperationAction =
  | "restaurant_activate" | "restaurant_inactivate" | "restaurant_publish" | "restaurant_unpublish"
  | "tenant_suspend" | "tenant_unsuspend" | "security_flag_set" | "security_flag_clear"
  | "owner_membership_repair" | "staff_suspend" | "staff_reactivate" | "staff_invitation_revoke"
  | "customer_membership_repair" | "customer_deactivate" | "customer_reactivate"
  | "points_support_correction" | "qr_invalidate" | "gift_presentation_expire" | "transactional_mail_retry";

export type PlatformRestaurantOperations = {
  contract_version: "platform_admin_operations_v1_1";
  restaurant: { id: string; name: string; status: RestaurantStatus; organization_status: RestaurantStatus | null; published: boolean; branch_id: string | null };
  owner: { user_id: string; email: string | null; email_confirmed: boolean; last_sign_in_at: string | null; membership_present: boolean; memberships: Array<{ restaurant_id: string; role: string; created_at: string }> };
  staff: Array<{ id: string; name: string; email: string | null; role: string; status: string; active: boolean; auth_linked: boolean; membership_present: boolean; last_invited_at: string | null }>;
  customers: Array<{ id: string; name: string; points_balance: number; membership_status: string; auth_linked: boolean; central_membership_present: boolean; account_disabled: boolean }>;
  points_journal: Array<{ id: string; customer_id: string; type: string; points: number; reason: string; source: string | null; staff_user_id: string | null; created_at: string }>;
  gifts: Array<{ id: string; customer_id: string; reward_id: string; status: string; gift_type: string | null; created_at: string; redeemed_at: string | null }>;
  gift_presentations: Array<{ id: string; customer_id: string; customer_reward_id: string; status: string; expires_at: string; redeemed_at: string | null; expired_at: string | null; created_at: string }>;
  redemptions: Array<{ id: string; customer_id: string | null; reward_type: string; status: string; redeemed_at: string; actor_role: string }>;
  qr_evidence: Array<{ id: string; customer_id: string; expires_at: string; consumed_at: string | null; revoked_at: string | null; created_at: string }>;
  pin_evidence: Array<{ id: string; customer_id: string; valid_date: string; failed_attempts: number; locked_until: string | null; last_failed_at: string | null }>;
  mail_queue: Array<{ id: string; customer_id: string; event_type: string; status: string; attempt_count: number; available_at: string; failed_at: string | null; last_error_code: string | null }>;
  security_flags: Array<{ id: string; flag_key: string; status: string; reason: string; opened_at: string; cleared_at: string | null }>;
  operations: Array<{ id: string; action_type: string; entity_type: string; entity_id: string | null; severity: "NORMAL" | "SENSITIVE" | "CRITICAL"; reason: string | null; support_reference: string | null; result: string; created_at: string }>;
};

export async function loadPlatformRestaurants() {
  if (!supabase) {
    return { summary: emptySummary, restaurants: [] };
  }

  const { data, error } = await supabase.rpc("get_platform_restaurants");
  if (error) {
    throw error;
  }

  const payload = (data ?? {}) as PlatformRestaurantsResponse;
  return {
    summary: normalizeSummary(payload.summary),
    restaurants: payload.restaurants ?? [],
  };
}

export async function loadPlatformRestaurantDetail(restaurantId: string): Promise<PlatformRestaurantDetail> {
  if (!supabase) {
    throw new Error("Supabase ist nicht konfiguriert.");
  }

  const { data, error } = await supabase.rpc("get_platform_restaurant_detail", {
    input_restaurant_id: restaurantId,
  });

  if (error) {
    throw error;
  }

  return data as PlatformRestaurantDetail;
}

export async function loadPlatformRestaurantControlCenter(
  restaurantId: string,
): Promise<PlatformRestaurantControlCenter> {
  if (!supabase) {
    throw new Error("Supabase ist nicht konfiguriert.");
  }

  const { data, error } = await supabase.rpc("get_platform_restaurant_control_center", {
    input_restaurant_id: restaurantId,
  });

  if (error) {
    throw error;
  }

  return data as PlatformRestaurantControlCenter;
}

export async function loadPlatformRestaurantLegalI18nStatus(
  restaurantId: string,
): Promise<PlatformRestaurantLegalI18nStatus> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("get_platform_restaurant_legal_i18n_status", {
    input_restaurant_id: restaurantId,
  });
  if (error) throw error;
  return data as PlatformRestaurantLegalI18nStatus;
}

export type PlatformKassaComplianceStatus = { contract_version: string; required_text_version: string; acknowledgement_count: number; open_count: number; recorded_count: number; owner_reviewed_count: number; last_transition_at: string | null };
export async function loadPlatformKassaComplianceStatus(restaurantId: string): Promise<PlatformKassaComplianceStatus> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("get_platform_kassa_compliance_status", { input_restaurant_id: restaurantId });
  if (error) throw error;
  return data as PlatformKassaComplianceStatus;
}

export type PlatformTestTenantCleanupPreflight = {
  blockers: string[];
  contract_version: string;
  deleted?: boolean;
  eligible: boolean;
  inventory?: Record<string, number>;
  marking_preflight?: { blockers: string[]; eligible: boolean };
  restaurant_id?: string;
  restaurant_name?: string;
  test_session_id?: string | null;
};

export async function loadPlatformTestTenantCleanupPreflight(
  restaurantId: string,
): Promise<PlatformTestTenantCleanupPreflight> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("get_platform_test_tenant_cleanup_preflight", {
    input_restaurant_id: restaurantId,
  });
  if (error) throw error;
  return data as PlatformTestTenantCleanupPreflight;
}

export async function markPlatformTestTenant(input: {
  confirmation: string;
  idempotencyKey: string;
  reason: string;
  restaurantId: string;
  testSessionId: string;
}): Promise<PlatformTestTenantCleanupPreflight> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("mark_platform_test_tenant", {
    input_confirmation: input.confirmation,
    input_idempotency_key: input.idempotencyKey,
    input_reason: input.reason,
    input_restaurant_id: input.restaurantId,
    input_test_session_id: input.testSessionId,
  });
  if (error) throw error;
  return data as PlatformTestTenantCleanupPreflight;
}

export async function cleanupPlatformTestTenant(input: {
  confirmation: string;
  reason: string;
  restaurantId: string;
}): Promise<{ deleted: boolean; inventory: Record<string, number>; restaurant_id: string; test_session_id: string }> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("cleanup_platform_test_tenant", {
    input_confirmation: input.confirmation,
    input_reason: input.reason,
    input_restaurant_id: input.restaurantId,
  });
  if (error) throw error;
  return data as { deleted: boolean; inventory: Record<string, number>; restaurant_id: string; test_session_id: string };
}

export type PlatformForeignTestCustomerCleanupPreflight = {
  auth_user_id?: string;
  blockers: string[];
  contract_version: string;
  customer_account_id?: string;
  customer_id?: string;
  customer_name?: string;
  eligible: boolean;
  foreign_data_to_be_changed?: number;
  foreign_point_transactions?: number;
  foreign_restaurant_memberships?: number;
  local_gifts?: number;
  local_membership_id?: string;
  local_notifications?: number;
  local_point_balance?: number;
  local_point_transactions?: number;
  local_redemptions?: number;
  local_rewards?: number;
  local_row_ids?: Record<string, string[] | string | null>;
  local_visits_events?: number;
  test_tenant?: { id: string; name: string };
};

export async function loadPlatformForeignTestCustomerCleanupPreflight(
  restaurantId: string,
): Promise<PlatformForeignTestCustomerCleanupPreflight> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("get_platform_foreign_test_customer_cleanup_preflight", {
    input_restaurant_id: restaurantId,
  });
  if (error) throw error;
  return data as PlatformForeignTestCustomerCleanupPreflight;
}

export async function cleanupPlatformForeignTestCustomerRelation(input: {
  accountId: string;
  confirmation: string;
  customerId: string;
  customerName: string;
  reason: string;
  restaurantId: string;
}): Promise<{ removed: boolean; foreign_memberships_preserved: number; foreign_points_preserved: number }> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("cleanup_platform_foreign_test_customer_relation", {
    input_account_id: input.accountId,
    input_confirmation: input.confirmation,
    input_customer_id: input.customerId,
    input_expected_customer_name: input.customerName,
    input_reason: input.reason,
    input_restaurant_id: input.restaurantId,
  });
  if (error) throw error;
  return data as { removed: boolean; foreign_memberships_preserved: number; foreign_points_preserved: number };
}

export async function loadPlatformOperationalTelemetry(): Promise<PlatformOperationalTelemetry> {
  if (!supabase) {
    throw new Error("Supabase ist nicht konfiguriert.");
  }

  const { data, error } = await supabase.rpc("get_platform_operational_telemetry");
  if (error) {
    throw error;
  }

  return data as PlatformOperationalTelemetry;
}

export async function loadPlatformHealthCenter(): Promise<PlatformHealthCenter> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("get_platform_health_center");
  if (error) throw error;
  return data as PlatformHealthCenter;
}

export async function loadPlatformRestaurantOperations(restaurantId: string): Promise<PlatformRestaurantOperations> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("get_platform_restaurant_operations", { input_restaurant_id: restaurantId });
  if (error) throw error;
  return data as PlatformRestaurantOperations;
}

export async function loadRestaurantEntitlements(restaurantId: string): Promise<RestaurantEntitlements> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("get_restaurant_entitlements", {
    input_restaurant_id: restaurantId,
  });
  if (error) throw error;
  return data as RestaurantEntitlements;
}


export async function submitPlatformPlanOverride(input: import('./planOverrideRequest.mjs').PlanOverrideRequest) {
  if (!supabase) throw new Error('Supabase ist nicht konfiguriert.');
  const common = {
    input_restaurant_id: input.restaurantId,
    input_reason: input.reason,
    input_confirmation: input.confirmation,
    input_idempotency_key: input.idempotencyKey,
  };
  const { data, error } = input.action === 'activate'
    ? await supabase.rpc('set_platform_restaurant_plan_override', {
      ...common, input_plan_key: 'PRO', input_expires_at: input.expiresAt,
      input_starts_at: input.startsAt,
    })
    : await supabase.rpc('end_platform_restaurant_plan_override', { ...common, input_override_id: input.overrideId });
  if (error) throw error;
  return data as { success: boolean; idempotent: boolean; operation_id: string; entitlements: RestaurantEntitlements };
}

export async function executePlatformAdminOperation(input: {
  restaurantId: string;
  action: PlatformOperationAction;
  entityId?: string | null;
  reason?: string;
  supportReference?: string;
  confirmation?: string;
  payload?: Record<string, unknown>;
}) {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("execute_platform_admin_operation", {
    input_restaurant_id: input.restaurantId,
    input_action: input.action,
    input_entity_id: input.entityId ?? null,
    input_reason: input.reason ?? null,
    input_support_reference: input.supportReference ?? null,
    input_confirmation: input.confirmation ?? null,
    input_idempotency_key: crypto.randomUUID(),
    input_payload: input.payload ?? {},
  });
  if (error) throw error;
  return data as { success: boolean; operation_id: string };
}

export async function markPlatformCustomerTestMode(customerId: string, testSessionId: string) {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc("set_platform_customer_test_mode", {
    input_customer_id: customerId,
    input_is_test_customer: true,
    input_test_session_id: testSessionId,
  });
  if (error) throw error;
  return data as { customer_id: string; is_test_customer: boolean; test_session_id: string };
}

export async function requestPlatformAuthSupport(input: {
  restaurantId: string;
  entityId: string;
  action: "owner_confirmation_resend" | "owner_password_recovery" | "staff_invitation_resend";
  reason: string;
  supportReference?: string;
}) {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { error } = await supabase.functions.invoke("platform-support-auth", {
    body: { ...input, idempotencyKey: crypto.randomUUID() },
  });
  if (error) throw new Error("E-Mail-Aktion konnte nicht ausgeführt werden.");
}

export async function updatePlatformRestaurantSubscription(input: {
  restaurantId: string;
  confirmation: string;
  idempotencyKey: string;
  subscriptionStatus?: SubscriptionStatus | null;
  paymentStatus?: PaymentStatus | null;
  restaurantStatus?: RestaurantStatus | null;
  trialExtensionDays?: number | null;
  reason?: string | null;
}) {
  if (!supabase) {
    throw new Error("Supabase ist nicht konfiguriert.");
  }

  const { error } = await supabase.rpc("update_platform_restaurant_subscription_confirmed", {
    input_restaurant_id: input.restaurantId,
    input_subscription_status: input.subscriptionStatus ?? null,
    input_payment_status: input.paymentStatus ?? null,
    input_restaurant_status: input.restaurantStatus ?? null,
    input_trial_extension_days: input.trialExtensionDays ?? null,
    input_reason: input.reason ?? null,
    input_confirmation: input.confirmation,
    input_idempotency_key: input.idempotencyKey,
  });

  if (error) {
    throw error;
  }
}

export async function loadPlatformAuditEvents(filters: PlatformAuditFilters = {}): Promise<PlatformAuditEvent[]> {
  if (!supabase) {
    throw new Error("Supabase ist nicht konfiguriert.");
  }

  const { data, error } = await supabase.rpc("get_platform_audit_events", {
    input_from: filters.from ?? null,
    input_to: filters.to ?? null,
    input_restaurant_id: filters.restaurantId ?? null,
    input_customer_id: filters.customerId ?? null,
    input_event_type: filters.eventType ?? null,
    input_status: filters.status ?? null,
    input_source: filters.source ?? null,
    input_actor_type: filters.actorType ?? null,
    input_test_only: filters.testOnly ?? false,
    input_failed_only: filters.failedOnly ?? false,
    input_limit: filters.limit ?? 100,
  });

  if (error) throw error;
  return (data ?? []) as PlatformAuditEvent[];
}

export type ProCountryStatus = {
  country_code: string; release_state: "LOCKED" | "RELEASED"; effective_from: string | null;
  last_changed_at: string | null; last_actor_id: string | null; last_actor_role: string | null;
  last_reason: string | null; active_paid_count: number; active_trial_count: number;
  active_pilot_count: number; active_test_only_count: number; active_entitlement_count: number;
};
export type ProGrantState = "active" | "expired" | "revoked" | "scheduled";
export type ProEntitlement = {
  grant_id: string; organization_id: string; organization_name: string; restaurant_id: string;
  business_name: string; country_code: string; grant_type: "paid" | "trial" | "pilot" | "test_only";
  grant_state: ProGrantState; starts_at: string | null; expires_at: string | null;
  created_by: string | null; reason: string | null; revoked_by: string | null;
  revoked_at: string | null; revoke_reason: string | null; effective_plan: string;
  locations: Array<{ name: string; city: string | null; postal_code: string | null; country_code: string }>;
};
export type ProBusiness = {
  organization_id: string; organization_name: string; restaurant_id: string; business_name: string;
  country_code: string; stored_plan?: string | null; effective_plan: string;
  subscription_status?: string | null; payment_status?: string | null;
  country_release_state?: string | null; locations: ProEntitlement["locations"];
  pilot?: { grant_id?: string; starts_at?: string; expires_at?: string; state?: string };
  grant?: { grant_id?: string; starts_at?: string; expires_at?: string; state?: string };
};
export type ProCommercialAudit = {
  id: string; action: string; country_code: string | null; organization_name: string | null;
  business_name: string | null; grant_id: string | null; actor_role: string; created_at: string;
  reason: string; idempotency_reference: string; result: string;
};
type Paged<T> = { items: T[]; total: number; limit: number; offset: number };

async function proRpc<T>(name: string, input: Record<string, unknown>): Promise<T> {
  if (!supabase) throw new Error("Supabase ist nicht konfiguriert.");
  const { data, error } = await supabase.rpc(name, input);
  if (error) throw error;
  return data as T;
}

export async function loadProCountryStatus(country: string | null = null) {
  return proRpc<{ items: ProCountryStatus[]; count: number }>("get_platform_pro_country_status", { input_country: country });
}
export async function loadProEntitlements(input: { country?: string; grantType?: string; state?: string; search?: string; limit?: number; offset?: number } = {}) {
  return proRpc<Paged<ProEntitlement>>("get_platform_pro_entitlements", {
    input_country: input.country || null, input_grant_type: input.grantType || null,
    input_state: input.state || null, input_search: input.search || null,
    input_limit: input.limit ?? 50, input_offset: input.offset ?? 0,
  });
}
export async function searchProRealBusinesses(search = "", country = "") {
  return proRpc<Paged<ProBusiness>>("search_platform_pro_real_businesses", {
    input_search: search || null, input_country: country || null, input_limit: 50, input_offset: 0,
  });
}
export async function loadProTestOnlyBusinesses(search = "", country = "") {
  return proRpc<Paged<ProBusiness>>("get_platform_pro_test_only_businesses", {
    input_search: search || null, input_country: country || null, input_limit: 50, input_offset: 0,
  });
}
export async function loadProCommercialAudit(country = "") {
  return proRpc<Paged<ProCommercialAudit>>("get_platform_pro_commercial_audit", {
    input_country: country || null, input_action: null, input_restaurant_id: null, input_limit: 50, input_offset: 0,
  });
}
export async function setProCountryRelease(input: { country: string; release: boolean; reason: string; confirmation: string; requestId: string }) {
  return proRpc<Record<string, unknown>>("set_platform_commercial_pro_country_release", {
    input_country: input.country, input_release: input.release, input_reason: input.reason,
    input_confirmation: input.confirmation, input_request_id: input.requestId,
  });
}
export async function setProAccess(input: { restaurantId: string; accessKind: "REAL_BUSINESS_PILOT" | "INTERNAL_TEST_ONLY"; action: "GRANT" | "EXTEND" | "REVOKE"; startsAt: string | null; expiresAt: string | null; reason: string; confirmation: string; requestId: string }) {
  return proRpc<Record<string, unknown>>("set_platform_commercial_pro_access", {
    input_restaurant_id: input.restaurantId, input_access_kind: input.accessKind,
    input_action: input.action, input_starts_at: input.startsAt, input_expires_at: input.expiresAt,
    input_reason: input.reason, input_confirmation: input.confirmation, input_request_id: input.requestId,
  });
}
