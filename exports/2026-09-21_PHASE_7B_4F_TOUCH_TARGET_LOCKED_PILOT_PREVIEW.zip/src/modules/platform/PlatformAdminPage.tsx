import { useCallback, useEffect, useMemo, useState } from "react";
import { AlertCircle, Building2, CheckCircle2, Clock, Lock, RefreshCw, Search } from "lucide-react";
import { useLocation, useNavigate, useParams, useSearchParams } from "react-router-dom";
import {
  loadPlatformRestaurantControlCenter,
  loadPlatformRestaurants,
  loadPlatformOperationalTelemetry,
  updatePlatformRestaurantSubscription,
  type PaymentStatus,
  type PlatformRestaurant,
  type PlatformRestaurantControlCenter,
  type PlatformOperationalTelemetry,
  type PlatformSummary,
  type RestaurantStatus,
  type SubscriptionStatus,
} from "./platformAdminService";
import { PlatformRestaurantControlCenter as RestaurantControlCenter } from "./PlatformRestaurantControlCenter";
import { PlatformOperationalTelemetry as OperationalTelemetry } from "./PlatformOperationalTelemetry";
import { useAuth } from "../auth/AuthProvider";
import { canWritePlatformAdmin } from "./platformAdminAuthorization.mjs";
import { PlatformCountryLaunchPanel } from "./PlatformCountryLaunchPanel";
import { PlatformProControlCenter } from "./PlatformProControlCenter";
import { PlatformAdminLayout } from "./PlatformAdminLayout";
import { platformAdminNavigationMessages, type PlatformAdminSection } from "./platformAdminNavigationI18n";
import { useI18n } from "../../shared/i18n/I18nProvider";

const emptySummary: PlatformSummary = {
  restaurants_total: 0,
  active_restaurants: 0,
  active_trials: 0,
  expiring_trials: 0,
  expired_trials: 0,
  suspended_restaurants: 0,
  new_restaurants_today: 0,
  active_subscriptions: 0,
  open_payments: 0,
  points_today: 0,
  redemptions_today: 0,
};

const subscriptionLabels: Record<SubscriptionStatus, string> = {
  trialing: "Testphase",
  active: "Abo aktiv",
  past_due: "Überfällig",
  unpaid: "Unbezahlt",
  cancelled: "Gekündigt",
  paused: "Pausiert",
};

const restaurantStatusLabels: Record<RestaurantStatus, string> = {
  active: "Aktiv",
  draft: "Inaktiv",
  suspended: "Gesperrt",
};

const roleLabels: Record<string, string> = {
  platform_owner: "Plattformleitung",
  platform_admin: "Plattform Admin",
  app_admin: "App Admin",
  super_admin: "Super Admin",
  wuxuai_admin: "WUXUAI Admin",
  support: "Support",
  billing_admin: "Abrechnung",
  security_admin: "Sicherheit",
  viewer: "Nur Ansicht",
};

type FilterKey = "all" | "active" | "paused" | "suspended" | "trial" | "expiring" | "new" | "setup";

const filterKeys: FilterKey[] = ["all", "active", "paused", "suspended", "trial", "expiring", "new", "setup"];

function filterFromUrl(value: string | null): FilterKey {
  return filterKeys.includes(value as FilterKey) ? value as FilterKey : "all";
}

function isToday(value: string | null | undefined) {
  if (!value) return false;
  return new Date(value).toDateString() === new Date().toDateString();
}

function trialLabel(restaurant: PlatformRestaurant) {
  if (!restaurant.subscription_exists) return "Kein Abo eingerichtet";
  if (restaurant.subscription_status !== "trialing") {
    return restaurant.subscription_status ? subscriptionLabels[restaurant.subscription_status] : "Kein Abo eingerichtet";
  }
  if (restaurant.trial_ends_at && new Date(restaurant.trial_ends_at).getTime() < Date.now()) return "Testphase abgelaufen";
  return `Noch ${restaurant.trial_days_left ?? 0} Tage`;
}

function setupLabel(restaurant: PlatformRestaurant) {
  return restaurant.onboarding_status === "completed" || restaurant.onboarding_status === "ready" ? "Ja" : "Nein";
}

function computeSummary(restaurants: PlatformRestaurant[], summary: PlatformSummary): PlatformSummary {
  const now = Date.now();
  const sevenDays = 7 * 24 * 60 * 60 * 1000;
  return {
    ...summary,
    active_restaurants: restaurants.filter((restaurant) => restaurant.status === "active").length,
    expiring_trials: restaurants.filter((restaurant) => restaurant.subscription_exists && restaurant.subscription_status === "trialing" && restaurant.trial_ends_at && new Date(restaurant.trial_ends_at).getTime() >= now && new Date(restaurant.trial_ends_at).getTime() <= now + sevenDays).length,
    suspended_restaurants: restaurants.filter((restaurant) => restaurant.status === "suspended").length,
    new_restaurants_today: restaurants.filter((restaurant) => isToday(restaurant.created_at)).length,
  };
}

export function PlatformAdminPage() {
  const { platformRole, signOut } = useAuth();
  const { language } = useI18n();
  const routeParams = useParams();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const section: PlatformAdminSection = pathname.includes("/pro") ? "pro" : pathname.includes("/countries") ? "countries"
    : pathname.includes("/plans") ? "plans"
      : pathname.includes("/system") ? "system"
        : pathname.includes("/businesses") || pathname.includes("/restaurants") || pathname === "/platform-admin/restaurants" ? "businesses"
          : "overview";
  const showRestaurantWorkspace = section === "businesses" || section === "plans" || section === "system";
  const wildcardSegments = (routeParams["*"] ?? "").split("/").filter(Boolean);
  const restaurantId = routeParams.restaurantId ?? (showRestaurantWorkspace ? wildcardSegments[1] : undefined);
  const navigationText = platformAdminNavigationMessages(language);
  const [summary, setSummary] = useState<PlatformSummary>(emptySummary);
  const [restaurants, setRestaurants] = useState<PlatformRestaurant[]>([]);
  const [selectedRestaurantId, setSelectedRestaurantId] = useState<string | null>(restaurantId ?? null);
  const [detail, setDetail] = useState<PlatformRestaurantControlCenter | null>(null);
  const [telemetry, setTelemetry] = useState<PlatformOperationalTelemetry | null>(null);
  const [telemetryLoading, setTelemetryLoading] = useState(true);
  const [telemetryError, setTelemetryError] = useState("");
  const [searchTerm, setSearchTerm] = useState(() => searchParams.get("query") ?? "");
  const [filter, setFilter] = useState<FilterKey>(() => filterFromUrl(searchParams.get("status")));
  const [loading, setLoading] = useState(true);
  const [detailLoading, setDetailLoading] = useState(false);
  const [savingId, setSavingId] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [detailError, setDetailError] = useState("");
  const canWrite = canWritePlatformAdmin(platformRole);

  const loadOverviewData = useCallback(async () => {
    setLoading(true);
    setTelemetryLoading(true);
    setErrorMessage("");
    setTelemetryError("");
    const telemetryRequest = loadPlatformOperationalTelemetry()
      .then(setTelemetry)
      .catch((error) => {
        console.error("Betriebsstatus konnte nicht geladen werden.", error);
        setTelemetry(null);
        setTelemetryError("Die globale Telemetriequelle ist nicht erreichbar.");
      })
      .finally(() => setTelemetryLoading(false));
    try {
      const data = await loadPlatformRestaurants();
      setSummary(computeSummary(data.restaurants, data.summary));
    } catch (error) {
      console.error("WUXUAI Admin Daten konnten nicht geladen werden.", error);
      setErrorMessage("Admin-Daten konnten gerade nicht geladen werden.");
      setSummary(emptySummary);
    } finally {
      setLoading(false);
      await telemetryRequest;
    }
  }, []);

  const loadRestaurantData = useCallback(async (preferredId: string | null) => {
    setLoading(true);
    setErrorMessage("");
    try {
      const data = await loadPlatformRestaurants();
      setRestaurants(data.restaurants);
      const nextSelectedId = preferredId && data.restaurants.some((restaurant) => restaurant.id === preferredId) ? preferredId : data.restaurants[0]?.id ?? null;
      setSelectedRestaurantId(nextSelectedId);
    } catch (error) {
      console.error("WUXUAI Admin Daten konnten nicht geladen werden.", error);
      setErrorMessage("Admin-Daten konnten gerade nicht geladen werden.");
      setRestaurants([]);
      setSelectedRestaurantId(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadDetail = useCallback(async (id: string) => {
    setDetailLoading(true);
    setDetail(null);
    setDetailError("");
    try {
      setDetail(await loadPlatformRestaurantControlCenter(id));
    } catch (error) {
      console.error("Restaurantdetails konnten nicht geladen werden.", error);
      setDetailError("Restaurantdaten konnten nicht geladen werden.");
    } finally {
      setDetailLoading(false);
    }
  }, []);

  useEffect(() => {
    setMessage("");
    setErrorMessage("");
    if (section === "overview") {
      setRestaurants([]);
      setSelectedRestaurantId(null);
      void loadOverviewData();
      return;
    }
    if (showRestaurantWorkspace) {
      setTelemetry(null);
      setTelemetryError("");
      setTelemetryLoading(false);
      void loadRestaurantData(restaurantId ?? null);
      return;
    }
    setRestaurants([]);
    setSelectedRestaurantId(null);
    setLoading(false);
    setTelemetryLoading(false);
  }, [loadOverviewData, loadRestaurantData, restaurantId, section, showRestaurantWorkspace]);
  useEffect(() => {
    setFilter(filterFromUrl(searchParams.get("status")));
    setSearchTerm(searchParams.get("query") ?? "");
  }, [searchParams]);
  useEffect(() => {
    if (!showRestaurantWorkspace || !selectedRestaurantId) {
      setDetail(null);
      setDetailError("");
      return;
    }
    void loadDetail(selectedRestaurantId);
  }, [loadDetail, selectedRestaurantId, showRestaurantWorkspace]);

  const selectedRestaurant = useMemo(() => restaurants.find((restaurant) => restaurant.id === selectedRestaurantId) ?? null, [restaurants, selectedRestaurantId]);
  const filteredRestaurants = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    return restaurants.filter((restaurant) => {
      const matchesSearch = !term || restaurant.name.toLowerCase().includes(term) || restaurant.slug.toLowerCase().includes(term) || (restaurant.owner_email ?? "").toLowerCase().includes(term);
      const matchesFilter = filter === "all" || (filter === "active" && restaurant.status === "active") || (filter === "paused" && restaurant.status === "draft") || (filter === "suspended" && restaurant.status === "suspended") || (filter === "trial" && restaurant.subscription_status === "trialing") || (filter === "expiring" && restaurant.subscription_status === "trialing" && restaurant.trial_days_left !== null && restaurant.trial_days_left <= 7) || (filter === "new" && isToday(restaurant.created_at)) || (filter === "setup" && restaurant.onboarding_status !== "completed" && restaurant.onboarding_status !== "ready");
      return matchesSearch && matchesFilter;
    });
  }, [filter, restaurants, searchTerm]);

  function selectRestaurant(id: string) {
    setSelectedRestaurantId(id);
    const base = section === "plans" ? "/admin/platform/plans" : section === "system" ? "/admin/platform/system" : "/admin/platform/businesses";
    const query = searchParams.toString();
    navigate(`${base}/${id}${query ? `?${query}` : ""}`, { replace: false });
  }

  function updateRestaurantFilters(nextFilter: FilterKey = filter, nextSearch = searchTerm) {
    const next = new URLSearchParams(searchParams);
    if (nextFilter === "all") next.delete("status"); else next.set("status", nextFilter);
    if (nextSearch.trim()) next.set("query", nextSearch); else next.delete("query");
    setFilter(nextFilter);
    setSearchTerm(nextSearch);
    setSearchParams(next, { replace: true });
  }

  async function runSubscriptionAction(actionLabel: string, payload: { restaurantId: string; confirmation: string; idempotencyKey: string; subscriptionStatus?: SubscriptionStatus | null; paymentStatus?: PaymentStatus | null; restaurantStatus?: RestaurantStatus | null; trialExtensionDays?: number | null; reason?: string | null }) {
    if (!selectedRestaurant || payload.restaurantId !== selectedRestaurant.id) throw new Error("Restaurant changed");
    setSavingId(selectedRestaurant.id);
    setMessage("");
    setErrorMessage("");
    try {
      await updatePlatformRestaurantSubscription(payload);
      setMessage(`${actionLabel} wurde gespeichert.`);
      await loadRestaurantData(selectedRestaurant.id);
      await loadDetail(selectedRestaurant.id);
    } catch (error) {
      console.error("Admin-Aktion konnte nicht gespeichert werden.", error);
      setErrorMessage("Änderung konnte nicht gespeichert werden.");
      throw error;
    } finally {
      setSavingId(null);
    }
  }

  const summaryCards: Array<{ label: string; value: number; icon: typeof Building2; filter: FilterKey }> = [
    { label: "Restaurants gesamt", value: summary.restaurants_total, icon: Building2, filter: "all" },
    { label: "Aktive Restaurants", value: summary.active_restaurants ?? 0, icon: CheckCircle2, filter: "active" },
    { label: "Testphasen aktiv", value: summary.active_trials, icon: Clock, filter: "trial" },
    { label: "Testphasen bald ablaufend", value: summary.expiring_trials ?? 0, icon: AlertCircle, filter: "expiring" },
    { label: "Gesperrte Restaurants", value: summary.suspended_restaurants ?? 0, icon: Lock, filter: "suspended" },
    { label: "Neue Restaurants heute", value: summary.new_restaurants_today ?? 0, icon: RefreshCw, filter: "new" },
  ];
  const filterOptions: { key: FilterKey; label: string }[] = [
    { key: "all", label: "Alle" }, { key: "active", label: "Aktiv" }, { key: "paused", label: "Inaktiv" },
    { key: "suspended", label: "Gesperrt" }, { key: "trial", label: "Testphase" }, { key: "setup", label: "Setup offen" },
  ];

  const detailView = section === "plans" ? "plans" : section === "system" ? "system" : "businesses";
  return (
    <PlatformAdminLayout
      description={navigationText.descriptions[section]}
      title={section === "overview" ? "WUXUAI Admin" : navigationText[section]}
      toolbar={<>
          <span className="pill">{platformRole ? roleLabels[platformRole] ?? "Plattform Admin" : "Plattform Admin"}</span>
          {section === "overview" ? <button className="button secondary" onClick={() => void loadOverviewData()} type="button"><RefreshCw size={18} />{navigationText.refresh}</button> : null}
          {showRestaurantWorkspace ? <button className="button secondary" onClick={() => void loadRestaurantData(selectedRestaurantId)} type="button"><RefreshCw size={18} />{navigationText.refresh}</button> : null}
          <button className="button secondary platform-admin-sign-out" onClick={signOut} type="button">{navigationText.signOut}</button>
      </>}
    >

      {message ? <p className="status-message" role="status">{message}</p> : null}
      {errorMessage ? <p className="status-message error" role="alert">{errorMessage}</p> : null}

      {section === "overview" ? <><section className="platform-kpi-grid" aria-label="WUXUAI Admin Übersicht">
        {summaryCards.map((card) => { const Icon = card.icon; return <button aria-pressed={filter === card.filter} className={`card platform-kpi-card${filter === card.filter ? " active" : ""}`} key={card.label} onClick={() => navigate(`/admin/platform/businesses${card.filter === "all" ? "" : `?status=${card.filter}`}`)} type="button"><Icon size={22} /><strong>{card.value}</strong><span>{card.label}</span></button>; })}
      </section>

      <OperationalTelemetry data={telemetry} error={telemetryError} loading={telemetryLoading} />
      </> : null}
      {section === "countries" ? <PlatformCountryLaunchPanel role={platformRole} /> : null}
      {section === "pro" ? <PlatformProControlCenter /> : null}

      {showRestaurantWorkspace ? <section className="platform-admin-grid">
        <div className="card platform-restaurant-list-card" id="platform-restaurant-list">
          <div className="section-heading"><h2>Restaurantliste</h2><p className="muted">Nur interne Plattformrollen sehen diese Daten.</p></div>
          <div className="platform-toolbar">
            <label className="platform-search" htmlFor="platform-restaurant-search"><Search size={18} /><input id="platform-restaurant-search" onChange={(event) => updateRestaurantFilters(filter, event.target.value)} placeholder="Restaurant suchen" type="search" value={searchTerm} /></label>
            <div className="platform-filter-row" aria-label="Restaurantfilter">{filterOptions.map((option) => <button className={`chip-button${filter === option.key ? " active" : ""}`} key={option.key} onClick={() => updateRestaurantFilters(option.key)} type="button">{option.label}</button>)}</div>
          </div>
          {loading ? <p className="muted">Restaurants werden geladen …</p> : null}
          {!loading && filteredRestaurants.length === 0 ? <div className="empty-state-card"><Building2 size={32} /><h3>Keine Restaurants gefunden</h3><p>Ändere Suche oder Filter, um weitere Restaurants zu sehen.</p></div> : null}
          <div className="platform-restaurant-list">{filteredRestaurants.map((restaurant) => <article className={`platform-restaurant-row${restaurant.id === selectedRestaurantId ? " selected" : ""}`} key={restaurant.id}><button onClick={() => selectRestaurant(restaurant.id)} type="button"><span><strong>{restaurant.name}</strong><small>{restaurant.slug}</small><small>{restaurant.owner_email ?? "Betreiber nicht bekannt"}</small></span><span className="platform-row-meta"><span>{restaurantStatusLabels[restaurant.status]}</span><span>{trialLabel(restaurant)}</span><span>Setup: {setupLabel(restaurant)}</span><span>{restaurant.customer_count} Gäste</span><span>Details öffnen</span></span></button></article>)}</div>
        </div>

        <div className="platform-control-column">
          {selectedRestaurant ? <RestaurantControlCenter canWrite={canWrite} data={detail} error={detailError} loading={detailLoading} onAction={runSubscriptionAction} onRetry={() => void loadDetail(selectedRestaurant.id)} restaurant={selectedRestaurant} saving={savingId === selectedRestaurant.id} view={detailView} /> : <div className="empty-state-card"><Building2 size={32} /><h3>Kein Restaurant ausgewählt</h3><p>Wähle ein Restaurant aus der Liste, um Details zu sehen.</p></div>}
        </div>
      </section> : null}
    </PlatformAdminLayout>
  );
}
