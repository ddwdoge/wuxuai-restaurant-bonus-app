import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Archive,
  Copy,
  Edit3,
  Eye,
  Image as ImageIcon,
  Mail,
  MousePointerClick,
  Newspaper,
  Plus,
  RefreshCw,
  Send,
  Trash2,
  XCircle,
} from "lucide-react";
import { useSearchParams } from "react-router-dom";
import { AppDrawer } from "../../../shared/components/AppDrawer";
import { SmartMediaFrame } from "../../../shared/components/SmartMediaFrame";
import { FormLabel, RequiredFieldsNote } from "../../../shared/components/FormLabel";
import { DEFAULT_REWARD_IMAGE_CROP, rewardImageCropFromRecord, type RewardImageCrop } from "../../../shared/rewardImageCrop";
import { useTenant } from "../../tenant/TenantProvider";
import { useI18n } from "../../../shared/i18n/I18nProvider";
import { formatLocaleDate } from "../../../shared/i18n/formatters.mjs";
import { OwnerRewardImageUploader } from "../components/OwnerRewardImageUploader";
import { OwnerRewardImageEditor } from "../components/OwnerRewardImageEditor";
import {
  removeOwnerRewardImageUpload,
  uploadOwnerRewardImage,
} from "../services/ownerRewardImageService";
import { useOwnerSmartSetupContinuation } from "../useOwnerSmartSetupContinuation";
import {
  changeRestaurantOfferStatus,
  deleteRestaurantOfferDraft,
  duplicateRestaurantOffer,
  formatRestaurantOfferSchedule,
  isRestaurantOfferCapacityError,
  loadRestaurantOfferBranches,
  loadRestaurantOfferEmailSummary,
  loadRestaurantOffers,
  loadOwnerOfferCapacity,
  loadOwnerOfferPlanWindow,
  restaurantOfferCustomerVisibility,
  restaurantOfferDisplayStatus,
  restaurantOfferPricePresentation,
  restaurantOfferValidityPresentation,
  restaurantOfferTypeLabels,
  restaurantOfferTypes,
  saveRestaurantOffer,
  type RestaurantOffer,
  type RestaurantOfferBranch,
  type RestaurantOfferEmailSummary,
  type RestaurantOfferType,
  type OwnerOfferCapacity,
  type OwnerOfferPlanWindow,
} from "../../offers/restaurantOfferService";
import { offerCapacityReachedMessage } from "../../offers/offerCapacityMessages.mjs";
import "./restaurant-offers.css";

type Filter = "all" | "published" | "draft" | "inactive";

type OfferForm = {
  id: string | null;
  branchId: string;
  offerType: RestaurantOfferType;
  title: string;
  shortDescription: string;
  description: string;
  imageUrl: string | null;
  imageCrop: RewardImageCrop;
  currentPrice: string;
  previousPrice: string;
  validFrom: string;
  validTo: string;
  weekdays: number[];
  timeFrom: string;
  timeTo: string;
  buttonLabel: string;
};

const weekdays = [
  { value: 1, label: "Mo" },
  { value: 2, label: "Di" },
  { value: 3, label: "Mi" },
  { value: 4, label: "Do" },
  { value: 5, label: "Fr" },
  { value: 6, label: "Sa" },
  { value: 7, label: "So" },
];

function localDateTime(value: Date) {
  const offset = value.getTimezoneOffset() * 60_000;
  return new Date(value.getTime() - offset).toISOString().slice(0, 16);
}

function newOfferForm(branchId = ""): OfferForm {
  const start = new Date();
  start.setMinutes(0, 0, 0);
  const end = new Date(start);
  end.setDate(end.getDate() + 7);
  return {
    id: null,
    branchId,
    offerType: "WEEKLY_OFFER",
    title: "",
    shortDescription: "",
    description: "",
    imageUrl: null,
    imageCrop: DEFAULT_REWARD_IMAGE_CROP,
    currentPrice: "",
    previousPrice: "",
    validFrom: localDateTime(start),
    validTo: localDateTime(end),
    weekdays: [],
    timeFrom: "",
    timeTo: "",
    buttonLabel: "Angebot ansehen",
  };
}

function offerToForm(offer: RestaurantOffer): OfferForm {
  return {
    id: offer.id,
    branchId: offer.branch_id,
    offerType: offer.offer_type,
    title: offer.title,
    shortDescription: offer.short_description,
    description: offer.description ?? "",
    imageUrl: offer.image_url,
    imageCrop: rewardImageCropFromRecord(offer),
    currentPrice: offer.current_price == null ? "" : String(offer.current_price),
    previousPrice: offer.previous_price == null ? "" : String(offer.previous_price),
    validFrom: localDateTime(new Date(offer.valid_from)),
    validTo: localDateTime(new Date(offer.valid_to)),
    weekdays: offer.weekdays ?? [],
    timeFrom: offer.time_from?.slice(0, 5) ?? "",
    timeTo: offer.time_to?.slice(0, 5) ?? "",
    buttonLabel: offer.button_label,
  };
}

function formatPeriod(offer: RestaurantOffer) {
  const formatter = new Intl.DateTimeFormat("de-AT", { day: "2-digit", month: "2-digit", year: "numeric" });
  return `${formatter.format(new Date(offer.valid_from))} – ${formatter.format(new Date(offer.valid_to))}`;
}

function statusTone(status: string) {
  if (status === "Veröffentlicht") return "active";
  if (status === "Entwurf") return "draft";
  if (status === "Abgelaufen") return "expired";
  return "inactive";
}

function OfferPreviewPrice({ offer }: { offer: RestaurantOffer }) {
  const price = restaurantOfferPricePresentation(offer.current_price, offer.previous_price);
  if (!price.currentPrice) return null;
  return (
    <div className="restaurant-offer-preview-price">
      {price.discountLabel ? <strong>{price.discountLabel}</strong> : null}
      {price.previousPrice ? <del>{price.previousPrice}</del> : null}
      <b>{price.currentPrice}</b>
    </div>
  );
}

export function RestaurantOffersPage() {
  const { language, translateKey } = useI18n();
  const [searchParams, setSearchParams] = useSearchParams();
  const routeCreateRequested = searchParams.get("create") === "1";
  const removePhotoLabel = translateKey("owner.auto_d2fe0400ed5b");
  const smartSetup = useOwnerSmartSetupContinuation();
  const { activeRestaurant } = useTenant();
  const restaurantId = activeRestaurant?.id ?? "";
  const [offers, setOffers] = useState<RestaurantOffer[]>([]);
  const [branches, setBranches] = useState<RestaurantOfferBranch[]>([]);
  const [emailSummary, setEmailSummary] = useState<RestaurantOfferEmailSummary | null>(null);
  const [capacity, setCapacity] = useState<OwnerOfferCapacity | null>(null);
  const [planWindow, setPlanWindow] = useState<OwnerOfferPlanWindow | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [previewOffer, setPreviewOffer] = useState<RestaurantOffer | null>(null);
  const [form, setForm] = useState<OfferForm>(() => newOfferForm());
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const firstInvalidRef = useRef<HTMLInputElement>(null);
  const routeCreateHandledRef = useRef(false);

  const reload = useCallback(async () => {
    if (!restaurantId) return;
    setLoading(true);
    setError(null);
    try {
      const [nextOffers, nextBranches, nextEmailSummary, nextCapacity, nextPlanWindow] = await Promise.all([
        loadRestaurantOffers(restaurantId),
        loadRestaurantOfferBranches(restaurantId),
        loadRestaurantOfferEmailSummary(restaurantId).catch(() => null),
        loadOwnerOfferCapacity(restaurantId).catch(() => null),
        loadOwnerOfferPlanWindow(restaurantId).catch(() => null),
      ]);
      setOffers(nextOffers);
      setBranches(nextBranches);
      setEmailSummary(nextEmailSummary);
      setCapacity(nextCapacity);
      setPlanWindow(nextPlanWindow);
    } catch (nextError) {
      setOffers([]);
      setBranches([]);
      setEmailSummary(null);
      setCapacity(null);
      setPlanWindow(null);
      setError(nextError instanceof Error ? nextError.message : "Angebote konnten nicht geladen werden.");
    } finally {
      setLoading(false);
    }
  }, [restaurantId]);

  useEffect(() => { void reload(); }, [reload]);
  useEffect(() => () => { if (photoPreview) URL.revokeObjectURL(photoPreview); }, [photoPreview]);

  const visibleOffers = useMemo(() => offers.filter((offer) => {
    const displayStatus = restaurantOfferDisplayStatus(offer);
    if (filter === "published") return displayStatus === "Veröffentlicht";
    if (filter === "draft") return displayStatus === "Entwurf";
    if (filter === "inactive") return ["Deaktiviert", "Abgelaufen", "Archiviert"].includes(displayStatus);
    return true;
  }), [filter, offers]);
  const activeOfferCount = capacity?.offers.usage
    ?? offers.filter((offer) => restaurantOfferCustomerVisibility(offer) === "Sichtbar").length;

  function presentOfferError(nextError: unknown, fallback: string) {
    return isRestaurantOfferCapacityError(nextError)
      ? offerCapacityReachedMessage(language)
      : nextError instanceof Error ? nextError.message : fallback;
  }

  const resetPhoto = useCallback(() => {
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    setPhotoFile(null);
    setPhotoPreview(null);
  }, [photoPreview]);

  const startCreate = useCallback(() => {
    resetPhoto();
    setForm(newOfferForm(branches[0]?.id ?? activeRestaurant?.primary_branch_id ?? ""));
    setFormError(null);
    setFormOpen(true);
  }, [activeRestaurant?.primary_branch_id, branches, resetPhoto]);

  useEffect(() => {
    if (!routeCreateRequested) {
      routeCreateHandledRef.current = false;
      return;
    }
    if (routeCreateHandledRef.current) return;
    routeCreateHandledRef.current = true;
    startCreate();
  }, [routeCreateRequested, startCreate]);

  function clearCreateRoute() {
    if (!routeCreateRequested) return;
    const next = new URLSearchParams(searchParams);
    next.delete("create");
    setSearchParams(next, { replace: true });
  }

  function startEdit(offer: RestaurantOffer) {
    resetPhoto();
    setForm(offerToForm(offer));
    setFormError(null);
    setFormOpen(true);
  }

  function closeForm() {
    if (saving) return;
    resetPhoto();
    setFormOpen(false);
    setFormError(null);
    clearCreateRoute();
  }

  function selectPhoto(file: File) {
    resetPhoto();
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
    setForm((current) => ({ ...current, imageCrop: DEFAULT_REWARD_IMAGE_CROP }));
  }

  function validateForm() {
    if (!form.title.trim() || !form.shortDescription.trim() || !form.branchId || !form.validFrom || !form.validTo) {
      return "Bitte fülle alle Pflichtfelder aus.";
    }
    if (new Date(form.validTo).getTime() <= new Date(form.validFrom).getTime()) {
      return "Das Ende muss nach dem Beginn liegen.";
    }
    const currentPrice = form.currentPrice ? Number(form.currentPrice.replace(",", ".")) : null;
    const previousPrice = form.previousPrice ? Number(form.previousPrice.replace(",", ".")) : null;
    if (currentPrice !== null && (!Number.isFinite(currentPrice) || currentPrice <= 0)) return "Der aktuelle Preis muss größer als 0 sein.";
    if (previousPrice !== null && (currentPrice === null || previousPrice <= currentPrice)) return "Der vorherige Preis muss über dem aktuellen Preis liegen.";
    if (form.offerType === "LUNCH_MENU" && (!form.weekdays.length || !form.timeFrom || !form.timeTo)) {
      return "Wähle für das Mittagsmenü mindestens einen Wochentag und ein Zeitfenster.";
    }
    if ((form.timeFrom && !form.timeTo) || (!form.timeFrom && form.timeTo) || (form.timeFrom && form.timeTo && form.timeTo <= form.timeFrom)) {
      return "Bitte gib ein vollständiges, gültiges Zeitfenster ein.";
    }
    return null;
  }

  async function saveForm() {
    if (!activeRestaurant?.id || saving) return;
    const validationError = validateForm();
    if (validationError) {
      setFormError(validationError);
      firstInvalidRef.current?.focus();
      return;
    }
    setSaving(true);
    setFormError(null);
    let uploadedPath: string | null = null;
    try {
      let imageUrl = form.imageUrl;
      if (photoFile) {
        const upload = await uploadOwnerRewardImage({
          restaurantId: activeRestaurant.id,
          folder: "offers",
          entityId: form.id,
          file: photoFile,
        });
        imageUrl = upload.publicUrl;
        uploadedPath = upload.objectPath;
      }
      await saveRestaurantOffer({
        id: form.id,
        restaurantId: activeRestaurant.id,
        branchId: form.branchId,
        offerType: form.offerType,
        title: form.title.trim(),
        shortDescription: form.shortDescription.trim(),
        description: form.description.trim() || null,
        imageUrl,
        imageZoom: form.imageCrop.zoom,
        imagePositionX: form.imageCrop.positionX,
        imagePositionY: form.imageCrop.positionY,
        currentPrice: form.currentPrice ? Number(form.currentPrice.replace(",", ".")) : null,
        previousPrice: form.previousPrice ? Number(form.previousPrice.replace(",", ".")) : null,
        validFrom: new Date(form.validFrom).toISOString(),
        validTo: new Date(form.validTo).toISOString(),
        weekdays: form.weekdays.length ? form.weekdays : null,
        timeFrom: form.timeFrom || null,
        timeTo: form.timeTo || null,
        buttonLabel: form.buttonLabel.trim() || "Angebot ansehen",
      });
      setStatusMessage(form.id ? "Angebot aktualisiert." : "Entwurf gespeichert.");
      resetPhoto();
      setFormOpen(false);
      clearCreateRoute();
      await reload();
    } catch (nextError) {
      if (uploadedPath) await removeOwnerRewardImageUpload(uploadedPath);
      setFormError(presentOfferError(nextError, "Das Angebot konnte nicht gespeichert werden."));
    } finally {
      setSaving(false);
    }
  }

  async function runAction(offer: RestaurantOffer, action: "PUBLISH" | "DISABLE" | "ARCHIVE") {
    if (!activeRestaurant?.id) return;
    setStatusMessage(null);
    try {
      await changeRestaurantOfferStatus(activeRestaurant.id, offer.id, action);
      setStatusMessage(action === "PUBLISH" ? "Angebot veröffentlicht." : action === "DISABLE" ? "Angebot deaktiviert." : "Angebot archiviert.");
      await reload();
      if (action === "PUBLISH") smartSetup.complete("offer_published");
    } catch (nextError) {
      setStatusMessage(presentOfferError(nextError, "Die Aktion konnte nicht abgeschlossen werden."));
    }
  }

  async function duplicateOffer(offer: RestaurantOffer) {
    if (!activeRestaurant?.id) return;
    try {
      await duplicateRestaurantOffer(activeRestaurant.id, offer.id);
      setStatusMessage("Kopie als Entwurf erstellt.");
      await reload();
    } catch (nextError) {
      setStatusMessage(presentOfferError(nextError, "Das Angebot konnte nicht dupliziert werden."));
    }
  }

  async function deleteDraft(offer: RestaurantOffer) {
    if (!activeRestaurant?.id) return;
    try {
      await deleteRestaurantOfferDraft(activeRestaurant.id, offer.id);
      setStatusMessage("Entwurf gelöscht.");
      await reload();
    } catch (nextError) {
      setStatusMessage(presentOfferError(nextError, "Der Entwurf konnte nicht gelöscht werden."));
    }
  }

  if (!activeRestaurant) return <section className="card premium-owner-management-state"><h1>Kein Restaurant ausgewählt</h1></section>;

  return (
    <div className="premium-owner-page restaurant-offers-page">
      <header className="premium-owner-page-header restaurant-offers-heading">
        <div><span className="premium-owner-kicker">Informationen für deine Gäste</span><h1>Aktuelles & Angebote</h1><p>Veröffentliche Menüs, Veranstaltungen und Neuigkeiten. Dein Paket bestimmt die Anzahl gleichzeitig aktiver Angebote.</p></div>
        <button className="button premium-owner-primary-action" onClick={startCreate} type="button"><Plus aria-hidden="true" size={19} />Neues Angebot erstellen</button>
      </header>

      {capacity ? <section className="restaurant-offer-entitlement-summary" aria-label="Paket und Angebotskapazität"><div><span>Aktuelles Paket</span><strong>{capacity.plan.plan_key === "BASIC" ? "Basic" : "Pro"}</strong></div><div><span>Aktive und geplante Angebote</span><strong>{`${capacity.offers.usage} / ${capacity.offers.effective_limit}`}</strong></div><p>Plan und Kapazität werden ausschließlich durch WUXUAI verwaltet.</p></section> : null}
      {planWindow?.effective_from || planWindow?.effective_until ? <dl className="platform-detail-list" data-i18n-skip="true">
        {([['start', planWindow.effective_from], ['end', planWindow.effective_until]] as const).map(([key, value]) => value && Number.isFinite(Date.parse(value)) ? <div key={key}><dt>{translateKey(`platform.planOverride.${key}`)}</dt><dd>{formatLocaleDate(value, language, { dateStyle: "medium", timeStyle: "short" })}</dd></div> : null)}
      </dl> : null}

      <section className="restaurant-offers-legal-note">
        <Newspaper aria-hidden="true" size={21} />
        <p><strong>Information statt Punkteeinlösung.</strong> Angebote verändern keine Punkte und erzeugen keine Einlösung. Das Restaurant ist für die Richtigkeit, Aktualität, Verfügbarkeit und rechtliche Zulässigkeit seiner Angebots-, Preis-, Produkt- und Bildangaben verantwortlich.</p>
      </section>

      <section className="restaurant-offer-email-summary" aria-labelledby="offer-email-summary-title">
        <div className="restaurant-offer-email-summary-heading">
          <Mail aria-hidden="true" size={21} />
          <div><span>Freiwillige Einwilligung</span><h2 id="offer-email-summary-title">Angebots-E-Mails</h2></div>
          <strong className={emailSummary?.available ? "available" : "unavailable"}>{emailSummary?.available ? "Verfügbar" : "Noch nicht verfügbar"}</strong>
        </div>
        {emailSummary?.available ? (
          <div className="restaurant-offer-email-metrics">
            <div><span>Bestätigt</span><strong>{emailSummary.confirmed_recipients}</strong></div>
            <div><span>Wöchentlich</span><strong>{emailSummary.weekly_recipients}</strong></div>
            <div><span>Monatlich</span><strong>{emailSummary.monthly_recipients}</strong></div>
            <div><span>Zugestellt</span><strong>{emailSummary.delivered}</strong></div>
            <div><span>Nächste Woche</span><strong>{emailSummary.next_weekly_period}</strong></div>
            <div><span>Nächster Monat</span><strong>{emailSummary.next_monthly_period}</strong></div>
          </div>
        ) : (
          <p>Der Versand bleibt deaktiviert, bis eine freigegebene Marketing-E-Mail-Infrastruktur mit Double-Opt-in eingerichtet ist. Es werden keine Empfängerlisten angezeigt und keine Angebots-E-Mails versendet.</p>
        )}
      </section>

      <div className="restaurant-offers-toolbar">
        <div aria-label="Angebote filtern" className="restaurant-offers-filters" role="group">
          {([['all', 'Alle'], ['published', 'Veröffentlicht'], ['draft', 'Entwürfe'], ['inactive', 'Inaktiv']] as const).map(([value, label]) => (
            <button aria-pressed={filter === value} className={filter === value ? "active" : ""} key={value} onClick={() => setFilter(value)} type="button">{label}</button>
          ))}
        </div>
        <span>
          <><strong>{capacity ? `${activeOfferCount} / ${capacity.offers.effective_limit}` : activeOfferCount}</strong>{" "}<span>Aktive und geplante Angebote</span></>
        </span>
      </div>

      {statusMessage ? <p aria-live="polite" className="restaurant-offers-message">{statusMessage}</p> : null}
      {loading ? (
        <section aria-busy="true" className="restaurant-offers-grid">{[0, 1, 2].map((item) => <div className="restaurant-offer-skeleton" key={item} />)}</section>
      ) : error ? (
        <section className="card premium-owner-management-state" role="alert"><RefreshCw aria-hidden="true" size={25} /><div><h2>Angebote konnten nicht geladen werden.</h2><p>{error}</p></div><button className="button" onClick={() => void reload()} type="button">Erneut versuchen</button></section>
      ) : visibleOffers.length ? (
        <section aria-label="Gespeicherte Angebote" className="restaurant-offers-grid">
          {visibleOffers.map((offer) => {
            const displayStatus = restaurantOfferDisplayStatus(offer);
            const validity = restaurantOfferValidityPresentation(offer);
            const customerVisibility = restaurantOfferCustomerVisibility(offer);
            const price = restaurantOfferPricePresentation(offer.current_price, offer.previous_price);
            return (
              <article className="restaurant-offer-card" key={offer.id}>
                <div className="restaurant-offer-media">
                  {offer.image_url ? <SmartMediaFrame alt={`Bild zu ${offer.title}`} imageUrl={offer.image_url} presentation={rewardImageCropFromRecord(offer)} /> : <span><ImageIcon aria-hidden="true" size={34} /></span>}
                  <span className={`restaurant-offer-status ${statusTone(displayStatus)}`}>{displayStatus}</span>
                </div>
                <div className="restaurant-offer-body">
                  <span className="restaurant-offer-type">{restaurantOfferTypeLabels[offer.offer_type]}</span>
                  <h2>{offer.title}</h2>
                  <p>{offer.short_description}</p>
                  <dl>
                    <div><dt>Kundensichtbarkeit</dt><dd>{customerVisibility}</dd></div>
                    <div><dt>Aktuelle Gültigkeit</dt><dd>{validity.label}</dd></div>
                    <div><dt>Zeitplan</dt><dd>{formatRestaurantOfferSchedule(offer)}</dd></div>
                    <div><dt>Zeitraum</dt><dd>{formatPeriod(offer)}</dd></div>
                    <div><dt>Standort</dt><dd>{offer.branch_name ?? activeRestaurant.name}</dd></div>
                    {price.currentPrice ? <div><dt>Preis</dt><dd>{price.discountLabel ? `${price.discountLabel} · ` : ""}{price.previousPrice ? `${price.previousPrice} → ` : ""}{price.currentPrice}</dd></div> : null}
                  </dl>
                  <div className="restaurant-offer-metrics"><span><Eye aria-hidden="true" size={16} />{offer.views ?? 0} Aufrufe</span><span><MousePointerClick aria-hidden="true" size={16} />{offer.clicks ?? 0} Klicks</span></div>
                  <div className="restaurant-offer-actions">
                    <button onClick={() => startEdit(offer)} type="button"><Edit3 aria-hidden="true" size={17} />Bearbeiten</button>
                    <button onClick={() => setPreviewOffer(offer)} type="button"><Eye aria-hidden="true" size={17} />Vorschau</button>
                    {offer.status === "DRAFT" || offer.status === "DISABLED" ? <button onClick={() => void runAction(offer, "PUBLISH")} type="button"><Send aria-hidden="true" size={17} />Veröffentlichen</button> : null}
                    {offer.status === "PUBLISHED" && offer.is_active ? <button onClick={() => void runAction(offer, "DISABLE")} type="button"><XCircle aria-hidden="true" size={17} />Deaktivieren</button> : null}
                    <button onClick={() => void duplicateOffer(offer)} type="button"><Copy aria-hidden="true" size={17} />Duplizieren</button>
                    {offer.status === "DRAFT" ? <button className="danger" onClick={() => void deleteDraft(offer)} type="button"><Trash2 aria-hidden="true" size={17} />Entwurf löschen</button> : offer.status !== "ARCHIVED" ? <button onClick={() => void runAction(offer, "ARCHIVE")} type="button"><Archive aria-hidden="true" size={17} />Archivieren</button> : null}
                  </div>
                </div>
              </article>
            );
          })}
        </section>
      ) : (
        <section className="restaurant-offers-empty"><Newspaper aria-hidden="true" size={34} /><h2>Noch keine Angebote</h2><p>Erstelle deinen ersten Informationsbeitrag für deine Gäste.</p><button className="button" onClick={startCreate} type="button">Neues Angebot erstellen</button></section>
      )}

      <AppDrawer className="owner-mobile-drawer" fitVisualViewport
        description="Erstelle oder bearbeite einen Informationsbeitrag."
        footer={<><button className="button secondary" disabled={saving} onClick={closeForm} type="button">Abbrechen</button><button className="button" disabled={saving} onClick={() => void saveForm()} type="button">{saving ? "Wird gespeichert …" : "Entwurf speichern"}</button></>}
        onClose={closeForm}
        open={formOpen}
        size="large"
        title={form.id ? "Angebot bearbeiten" : "Neues Angebot"}
      >
        <form className="restaurant-offer-form" onSubmit={(event) => { event.preventDefault(); void saveForm(); }}>
          <RequiredFieldsNote />
          {photoPreview || form.imageUrl ? (
            <div className="restaurant-offer-media-editor-block">
              <OwnerRewardImageEditor
                crop={form.imageCrop}
                disabled={saving}
                imageUrl={photoPreview ?? form.imageUrl ?? ""}
                label={form.title || "Angebot"}
                onCropChange={(imageCrop) => setForm((current) => ({ ...current, imageCrop }))}
                onFileSelected={selectPhoto}
              />
              <button
                aria-label={removePhotoLabel}
                className="button secondary restaurant-offer-remove-photo"
                disabled={saving}
                onClick={() => { resetPhoto(); setForm((current) => ({ ...current, imageUrl: null, imageCrop: DEFAULT_REWARD_IMAGE_CROP })); }}
                type="button"
              >
                <Trash2 aria-hidden="true" size={18} />{removePhotoLabel}
              </button>
            </div>
          ) : (
            <OwnerRewardImageUploader
              ariaLabel="Foto für das Angebot hinzufügen"
              categoryIcon={<ImageIcon aria-hidden="true" size={34} />}
              imageUrl={null}
              crop={form.imageCrop}
              label="Angebot"
              loading={saving && Boolean(photoFile)}
              onFileSelected={selectPhoto}
              previewUrl={null}
            />
          )}
          <div className="field"><FormLabel htmlFor="offer-title" required>Titel</FormLabel><input aria-required="true" id="offer-title" maxLength={120} onChange={(event) => setForm((current) => ({ ...current, title: event.target.value }))} ref={firstInvalidRef} required value={form.title} /></div>
          <div className="field"><FormLabel htmlFor="offer-type" required>Art des Beitrags</FormLabel><select aria-required="true" id="offer-type" onChange={(event) => setForm((current) => ({ ...current, offerType: event.target.value as RestaurantOfferType }))} required value={form.offerType}>{restaurantOfferTypes.map((type) => <option key={type} value={type}>{restaurantOfferTypeLabels[type]}</option>)}</select></div>
          <div className="field"><FormLabel htmlFor="offer-short" required>Kurzbeschreibung</FormLabel><textarea aria-required="true" id="offer-short" maxLength={240} onChange={(event) => setForm((current) => ({ ...current, shortDescription: event.target.value }))} required rows={3} value={form.shortDescription} /><small>{form.shortDescription.length}/240 Zeichen</small></div>
          <div className="field"><FormLabel htmlFor="offer-description" optional>Ausführliche Beschreibung</FormLabel><textarea id="offer-description" maxLength={4000} onChange={(event) => setForm((current) => ({ ...current, description: event.target.value }))} rows={5} value={form.description} /></div>
          <div className="restaurant-offer-form-grid">
            <div className="field"><FormLabel htmlFor="offer-price" optional>Aktueller Preis</FormLabel><input id="offer-price" inputMode="decimal" min="0.01" onChange={(event) => setForm((current) => ({ ...current, currentPrice: event.target.value }))} step="0.01" type="number" value={form.currentPrice} /></div>
            <div className="field"><FormLabel htmlFor="offer-previous-price" optional>Vorheriger Preis</FormLabel><input id="offer-previous-price" inputMode="decimal" min="0.01" onChange={(event) => setForm((current) => ({ ...current, previousPrice: event.target.value }))} step="0.01" type="number" value={form.previousPrice} /></div>
          </div>
          <p className="restaurant-offer-price-note">Du bist für die Richtigkeit und rechtliche Zulässigkeit deiner Preisangaben verantwortlich.</p>
          <div className="restaurant-offer-form-grid">
            <div className="field"><FormLabel htmlFor="offer-valid-from" required>Gültig von</FormLabel><input aria-required="true" id="offer-valid-from" onChange={(event) => setForm((current) => ({ ...current, validFrom: event.target.value }))} required type="datetime-local" value={form.validFrom} /></div>
            <div className="field"><FormLabel htmlFor="offer-valid-to" required>Gültig bis</FormLabel><input aria-required="true" id="offer-valid-to" onChange={(event) => setForm((current) => ({ ...current, validTo: event.target.value }))} required type="datetime-local" value={form.validTo} /></div>
          </div>
          <fieldset className="restaurant-offer-weekdays"><legend>Wochentage <span>Optional</span></legend>{weekdays.map((day) => <label key={day.value}><input checked={form.weekdays.includes(day.value)} onChange={(event) => setForm((current) => ({ ...current, weekdays: event.target.checked ? [...current.weekdays, day.value].sort() : current.weekdays.filter((value) => value !== day.value) }))} type="checkbox" />{day.label}</label>)}</fieldset>
          <div className="restaurant-offer-form-grid"><div className="field"><FormLabel htmlFor="offer-time-from" optional>Uhrzeit von</FormLabel><input id="offer-time-from" onChange={(event) => setForm((current) => ({ ...current, timeFrom: event.target.value }))} type="time" value={form.timeFrom} /></div><div className="field"><FormLabel htmlFor="offer-time-to" optional>Uhrzeit bis</FormLabel><input id="offer-time-to" onChange={(event) => setForm((current) => ({ ...current, timeTo: event.target.value }))} type="time" value={form.timeTo} /></div></div>
          <div className="field"><FormLabel htmlFor="offer-button" optional>Buttontext</FormLabel><input id="offer-button" maxLength={50} onChange={(event) => setForm((current) => ({ ...current, buttonLabel: event.target.value }))} value={form.buttonLabel} /></div>
          {formError ? <p className="restaurant-offer-form-error" role="alert">{formError}</p> : null}
        </form>
      </AppDrawer>

      <AppDrawer className="owner-mobile-drawer" fitVisualViewport description="So sehen Gäste den Beitrag." onClose={() => setPreviewOffer(null)} open={Boolean(previewOffer)} size="standard" title="Vorschau">
        {previewOffer ? <article className="restaurant-offer-customer-preview">{previewOffer.image_url ? <SmartMediaFrame alt={`Bild zu ${previewOffer.title}`} imageUrl={previewOffer.image_url} presentation={rewardImageCropFromRecord(previewOffer)} /> : <span><ImageIcon aria-hidden="true" size={34} /></span>}<div><small>{restaurantOfferTypeLabels[previewOffer.offer_type]}</small><h2>{previewOffer.title}</h2><p>{previewOffer.short_description}</p><OfferPreviewPrice offer={previewOffer} /><button className="button" type="button">{previewOffer.button_label}</button></div></article> : null}
      </AppDrawer>
    </div>
  );
}
