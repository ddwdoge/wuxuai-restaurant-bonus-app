# WUXUAI Premium Design Migration

Stand: 20.07.2026

## Ziel

Das Kundenportal wurde als warme, ruhige und mobile Premium-Oberfläche neu
strukturiert. Datenquellen, Authentifizierung, Kundentoken, Punkteberechnung,
Tages-PIN, Bonus Boost und Einlösung wurden nicht verändert.

## Umgebaute Bereiche

- Restaurant-QR-Einstieg und Registrierung
- Freunde-Einladung
- Kunden-Startansicht
- Punktekarte und Fortschritt
- Vorschau und Übersicht der Punkteeinlösungen
- Willkommens- und Geburtstagsgeschenke
- Einlösebestätigung und Einlösecode im Drawer
- Punkte sammeln mit Rechnungsbetrag und Tages-PIN
- Kundenkonto mit persönlichem QR und Speicherhilfe
- Lade-, Fehler- und Leerzustände

## Wiederverwendbare Komponenten

Unter `src/modules/customer/components/PremiumCustomerUi.tsx`:

- `AppShell`
- `CustomerHeader`
- `BottomNavigation`
- `PageContainer`
- `SectionHeader`
- `PremiumCard`
- `PointsCard`
- `RewardCard`
- `PrimaryButton`
- `SecondaryButton`
- `StatusBadge`
- `ProgressBar`
- `EmptyState`
- `LoadingState`
- `ErrorState`
- `PremiumDrawer`
- `ConfirmationDialog`
- `RestaurantLogo`
- `RewardImage`

## Design-Tokens

Die isolierten Kunden-Tokens stehen in
`src/modules/customer/customer-premium.css`.

- Hintergrund: `#f8f5ef`
- Oberfläche: `#ffffff`
- Primärakzent: `#b88a3b`
- Primärtext: `#1f1f1f`
- Sekundärtext: `#6f6a63`
- Erfolg: `#4f7a5b`
- Warnung: `#a87527`
- Fehler: `#a94c4c`

Gold wird nur für Hauptaktionen, Fortschritt, aktive Navigation und wichtige
Statushinweise verwendet.

## Navigation

Registrierte Gäste erhalten vier deutsche Hauptpunkte:

1. Start
2. Einlösen
3. Sammeln
4. Konto

`Sammeln` öffnet den bestehenden `/w/:slug`-Flow. Es wurde kein neuer
Punkteweg angelegt.

## Drawer

`So funktioniert's`, die Einlösebestätigung und der aktive Einlösecode nutzen
den gemeinsamen `AppDrawer`. Dieser unterstützt Overlay-Klick, Schließen-
Button, Escape, Fokus-Trap, Fokus-Rückgabe, Scroll-Lock und mobile Vollbreite.

## Nicht umgebaut

- Restaurant Portal
- Staff Portal
- WUXUAI Admin
- Datenbank, RPCs, RLS und Migrationen
- Authentifizierung und Kundentoken-Speicherung
- Bonus-, Punkte-, PIN-, Referral- und Einlöselogik

## Prüfung

- Typecheck: erfolgreich
- Tests: 26/26 erfolgreich
- Build: erfolgreich
- Lint: 0 Fehler; 11 bereits vorhandene Warnungen außerhalb dieses Scopes
- Responsive geprüft: 390 px, 768 px und 1440 px
- Kein horizontaler Überlauf auf den geprüften Breiten
- Info-Drawer mobil geöffnet und per Escape geschlossen
- Fokus-Rückgabe und Hintergrund-Scroll-Lock geprüft

## Staging-End-to-End-Prüfung

Am 20.07.2026 wurde über den vorgesehenen Registrierungs- und Onboarding-Flow
ein synthetisches Staging-Testrestaurant mit einem synthetischen Testgast
angelegt. Verwendet wurden weder Produktionskunden noch echte personenbezogene
Daten. Token, Telefonnummer, Tages-PIN und Einlösecode werden nicht
dokumentiert.

Geprüft wurden:

- registrierter Kundenflow mit echtem Customer Token
- Punktebuchung für die Bon-Stufe `20–30 €`: `0 → 20 Punkte`
- Punktestand nach Reload: `20 Punkte`
- Punkteeinlösung `Gratis Kaffee`: `20 → 0 Punkte`
- echter sechsstelliger Einlösecode, im Bericht nur als `*** ***` dargestellt
- erfolgreicher einmaliger Verbrauch im Staff-Portal
- erneute Codeverwendung serverseitig blockiert
- Info- und Einlösedrawer im echten Kundenflow
- 390 px, 768 px und 1440 px ohne horizontalen Überlauf

## Verbleibende Freigabeblocker

1. Nach erfolgreichem Verbrauch zeigt das Kundenportal den bis zum Ablauf in
   `sessionStorage` gespeicherten Code nach Reload weiterhin als aktiv. Der
   Server blockiert die Wiederverwendung korrekt, aber die sichtbare
   Statusanzeige ist falsch. Eine sichere Korrektur benötigt einen
   serverseitigen, tokengebundenen Statusabruf; ein reiner Frontend-Fallback
   wäre nicht belastbar.
2. Das Restaurant-Dashboard zeigt derzeit nicht alle für die Abnahme
   geforderten Kundenkennzahlen. Vorhanden und korrekt waren `Neue Mitglieder
   heute = 1` sowie `Vergebene Bonuspunkte heute = 20`. Separate Werte für
   `Kunden gesamt`, `Neue Kunden diese Woche` und `Heute aktiv` fehlen in der
   aktuellen V1-Dashboard-Oberfläche.

Der Premium-UI-Code ist geprüft, die Gesamtfreigabe bleibt bis zur Behebung
dieser beiden Punkte `NOT READY`.
